# Player Tracker — starter project

This is a working starter for the "AI watches the film and finds the player
itself" feature. It detects people in a soccer video, tracks each one across
frames, picks out the player whose shirt matches a color you give it, and cuts
that player's clips.

It is a **starting point built to be handed to Claude Code** (or a developer)
and grown from there. Read this whole page before running anything — it is
written for someone who has never run code before.

---

## What you're getting

- `track_player.py` — the actual program. Well-commented; the spots most worth
  adjusting are marked `>>> TUNE`.
- `requirements.txt` — the list of free libraries the program needs.
- `README.md` — this file.

## Honest expectations (read this first)

- **This runs on a computer, not in a browser or phone.** It's Python. You run
  it from a terminal (a text command window). The web app I built earlier is
  separate — this could feed clips into it later, but they're different pieces.
- **A regular laptop works, slowly.** It processes maybe a few frames per second
  on a normal computer, so a full match takes a while. A computer with a GPU
  (gaming graphics card) or a rented cloud machine is much faster.
- **It won't be perfect out of the box.** Telling apart players, especially two
  teams with similar colors or players who bunch together, is genuinely hard.
  The first run gives rough results; the `>>> TUNE` settings and Claude Code are
  how you improve them.
- **The simple version picks a player by SHIRT COLOR.** That works well when the
  two teams wear clearly different colors. Telling apart two players on the
  *same* team (by number, say) is a harder upgrade — noted at the bottom.

## What you need to install (one time)

1. **Python** — the language this is written in. Download from python.org
   (get version 3.10 or newer). During install on Windows, tick
   "Add Python to PATH."
2. **ffmpeg** — a free tool that cuts the video clips. Search "install ffmpeg"
   for your system, or your developer/Claude Code can set it up.

## How to run it

Open a terminal / command prompt, go to this folder, then:

```bash
# 1. Install the libraries (one time). This downloads the AI model too.
pip install -r requirements.txt

# 2. Just find the timestamps for a player in a red shirt:
python track_player.py --video game.mp4 --shirt "255,80,80"

# 3. Same, but also cut the actual video clips:
python track_player.py --video game.mp4 --shirt "255,80,80" --cut
```

- `--video` is the path to your match file.
- `--shirt` is the player's shirt color as Red,Green,Blue numbers (0–255).
  Red ≈ `255,80,80`, blue ≈ `60,90,220`, white ≈ `230,230,230`.
- Results land in an `output` folder: a `clips.json` file with the timestamps,
  and (if you used `--cut`) the clip videos.

### If it finds nothing

Open `output/clips.json` and look at the `tracks_debug` section. It lists every
person the program saw and the average shirt color it measured for them. Use
those real numbers to pick a better `--shirt` value, or raise `COLOR_TOLERANCE`
near the top of `track_player.py`.

---

## How the program works, in four steps

1. **Detect** — YOLO, a pretrained model, finds every person in each frame.
2. **Track** — ByteTrack gives each person a stable ID so they're the "same
   player" from frame to frame.
3. **Identify** — it samples each person's torso color and keeps the ones close
   to your target shirt color.
4. **Cut** — it merges those moments into clips and, optionally, exports them.

## Good things to ask Claude Code to do next

Paste any of these to Claude Code with this project open:

- "Tell players on the same team apart by jersey NUMBER, not just shirt color."
- "Draw the tracking box and ID onto a copy of the video so I can watch what it
  saw."
- "Speed it up by skipping every other frame, and let me set that from the
  command line."
- "Output the clips in the exact JSON format my web app's clip list expects."
- "Add a step that picks the two team colors automatically instead of me typing
  a shirt color."
- "Package this so it runs on a rented cloud GPU and I can send it a video and
  get clips back."

## The honest bottom line

Claude Code can absolutely write and improve this — the code above is proof it's
tractable, and each upgrade in that list is a normal Claude Code request. What
it can't remove is that this is a real system you run, feed footage, and tune,
with some ongoing compute cost if you move it to a server. It's the "grow into
it" path, and this file is a real first rung on that ladder.
