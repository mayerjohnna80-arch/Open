"""
track_player.py — Follow one player through a soccer match and cut their clips.

WHAT THIS DOES (plain English)
------------------------------
1. Reads a game video frame by frame.
2. Detects every person in each frame (YOLO, a pretrained model).
3. Tracks each person across frames so each keeps a stable ID number
   (ByteTrack, built into the ultralytics library).
4. Lets you pick ONE player by the color of their shirt.
5. Writes out the time ranges where that player is on screen, and
   (optionally) cuts those moments into short video clips.

This is a STARTER. It works, but real accuracy needs tuning — see the
places marked  >>> TUNE  below, and read README.md first.

HOW TO RUN (after following README.md setup)
--------------------------------------------
    python track_player.py --video game.mp4 --shirt "255,80,80" --cut

    --video   path to your match video
    --shirt   the player's shirt color as R,G,B (0-255). e.g. red ≈ 255,80,80
    --cut     also write video clips (leave off to just get timestamps)
"""

import argparse
import json
import os
import subprocess
from collections import defaultdict

import numpy as np

# ultralytics ships YOLO + ByteTrack together. cv2 (OpenCV) reads video/pixels.
from ultralytics import YOLO
import cv2


# ---------------------------------------------------------------------------
# Settings you may want to change are grouped here.
# ---------------------------------------------------------------------------

MODEL_NAME = "yolov8n.pt"   # 'n' = nano = fastest/least accurate.
                            # >>> TUNE: try "yolov8s.pt" or "yolov8m.pt" for
                            # better accuracy at the cost of speed.

PERSON_CLASS_ID = 0         # In the COCO dataset YOLO is trained on, 0 = person.

# How close a detected shirt color must be to your target to count as "your player."
# Lower = stricter. Colors are compared in 0-255 RGB distance.
COLOR_TOLERANCE = 60        # >>> TUNE: raise if it misses the player, lower if
                            # it grabs the wrong team.

# Merge on-screen stretches that are within this many seconds into one clip,
# and pad each clip by a little on both ends so plays aren't cut abruptly.
GAP_MERGE_SECONDS = 2.0     # >>> TUNE
CLIP_PAD_SECONDS = 1.5      # >>> TUNE
MIN_CLIP_SECONDS = 1.0      # ignore blips shorter than this


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def average_shirt_color(frame, box):
    """
    Estimate a player's shirt color by sampling the UPPER-MIDDLE of their
    bounding box (roughly the torso, avoiding head/shorts/legs).
    Returns an (R, G, B) tuple.
    """
    x1, y1, x2, y2 = [int(v) for v in box]
    h = y2 - y1
    w = x2 - x1
    if h <= 0 or w <= 0:
        return None

    # Torso region: vertically 20%-55% of the box, horizontally the middle 60%.
    ty1 = y1 + int(0.20 * h)
    ty2 = y1 + int(0.55 * h)
    tx1 = x1 + int(0.20 * w)
    tx2 = x1 + int(0.80 * w)

    patch = frame[ty1:ty2, tx1:tx2]
    if patch.size == 0:
        return None

    # OpenCV gives pixels as BGR; flip to RGB and average.
    avg_bgr = patch.reshape(-1, 3).mean(axis=0)
    return (float(avg_bgr[2]), float(avg_bgr[1]), float(avg_bgr[0]))


def color_distance(c1, c2):
    """Straight-line distance between two RGB colors."""
    return float(np.linalg.norm(np.array(c1) - np.array(c2)))


def merge_ranges(times, fps):
    """
    Turn a sorted list of frame indices where the player appeared into
    padded, merged (start_sec, end_sec) clip ranges.
    """
    if not times:
        return []

    times = sorted(times)
    # Group frame indices into runs separated by big gaps.
    runs = []
    run_start = times[0]
    prev = times[0]
    gap_frames = GAP_MERGE_SECONDS * fps

    for t in times[1:]:
        if t - prev > gap_frames:
            runs.append((run_start, prev))
            run_start = t
        prev = t
    runs.append((run_start, prev))

    # Convert to seconds, pad, drop tiny ones.
    clips = []
    for start_f, end_f in runs:
        start_s = max(0.0, start_f / fps - CLIP_PAD_SECONDS)
        end_s = end_f / fps + CLIP_PAD_SECONDS
        if end_s - start_s >= MIN_CLIP_SECONDS:
            clips.append((round(start_s, 2), round(end_s, 2)))
    return clips


def cut_clip(video, start_s, end_s, out_path):
    """
    Use ffmpeg to cut a clip. ffmpeg is a free tool the README tells you to
    install. This copies the video segment without re-encoding (fast).
    """
    dur = end_s - start_s
    cmd = [
        "ffmpeg", "-y",
        "-ss", str(start_s),
        "-i", video,
        "-t", str(dur),
        "-c", "copy",
        out_path,
    ]
    subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


# ---------------------------------------------------------------------------
# Main pipeline
# ---------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(description="Follow one player and cut their clips.")
    ap.add_argument("--video", required=True, help="path to the match video")
    ap.add_argument("--shirt", required=True, help="player shirt color as R,G,B (0-255)")
    ap.add_argument("--cut", action="store_true", help="also write video clips")
    ap.add_argument("--out", default="output", help="folder for results")
    args = ap.parse_args()

    target_color = tuple(float(x) for x in args.shirt.split(","))
    os.makedirs(args.out, exist_ok=True)

    # Video info
    cap = cv2.VideoCapture(args.video)
    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    cap.release()
    print(f"Video opens at ~{fps:.0f} frames/sec. Loading model '{MODEL_NAME}'...")

    model = YOLO(MODEL_NAME)

    # For each tracked person ID, remember their shirt-color samples and the
    # frames they appeared in. We decide WHO is our player after seeing enough.
    id_colors = defaultdict(list)     # track_id -> [ (r,g,b), ... ]
    id_frames = defaultdict(list)     # track_id -> [ frame_index, ... ]

    # model.track streams results frame by frame and assigns persistent IDs.
    print("Watching the film... (this is the slow part — minutes per match)")
    frame_idx = 0
    for result in model.track(
        source=args.video,
        stream=True,
        persist=True,
        classes=[PERSON_CLASS_ID],   # only track people
        tracker="bytetrack.yaml",    # >>> TUNE: botsort.yaml is an alternative
        verbose=False,
    ):
        frame = result.orig_img
        if result.boxes is not None and result.boxes.id is not None:
            boxes = result.boxes.xyxy.cpu().numpy()
            ids = result.boxes.id.cpu().numpy().astype(int)
            for box, tid in zip(boxes, ids):
                color = average_shirt_color(frame, box)
                if color is not None:
                    id_colors[tid].append(color)
                    id_frames[tid].append(frame_idx)
        frame_idx += 1

    total_frames = frame_idx
    print(f"Done watching. Saw {len(id_colors)} distinct people across {total_frames} frames.")

    # Which tracked IDs match our target shirt color on average?
    matched_frames = []
    per_id_report = []
    for tid, colors in id_colors.items():
        avg = tuple(np.mean(colors, axis=0))
        dist = color_distance(avg, target_color)
        is_match = dist <= COLOR_TOLERANCE
        per_id_report.append({
            "track_id": int(tid),
            "avg_color_rgb": [round(c) for c in avg],
            "distance_to_target": round(dist, 1),
            "matched": is_match,
            "frames_seen": len(id_frames[tid]),
        })
        if is_match:
            matched_frames.extend(id_frames[tid])

    clips = merge_ranges(matched_frames, fps)

    # Write a results file the web app (or you) can read.
    results = {
        "video": os.path.basename(args.video),
        "fps": round(fps, 2),
        "target_shirt_rgb": list(target_color),
        "color_tolerance": COLOR_TOLERANCE,
        "clips_seconds": [{"start": s, "end": e} for s, e in clips],
        "tracks_debug": sorted(per_id_report, key=lambda r: r["distance_to_target"]),
    }
    results_path = os.path.join(args.out, "clips.json")
    with open(results_path, "w") as f:
        json.dump(results, f, indent=2)

    print(f"\nFound {len(clips)} clip(s) for your player.")
    print(f"Timestamps + debug written to: {results_path}")
    if not clips:
        print("No clips matched. Open clips.json and look at 'tracks_debug' — the")
        print("'avg_color_rgb' values show what colors were actually on the field,")
        print("so you can pick a better --shirt value or raise COLOR_TOLERANCE.")

    # Optionally cut the actual video clips.
    if args.cut and clips:
        print("\nCutting clips with ffmpeg...")
        for i, (s, e) in enumerate(clips, 1):
            out_path = os.path.join(args.out, f"clip_{i:02d}_{s:.0f}s-{e:.0f}s.mp4")
            cut_clip(args.video, s, e, out_path)
            print(f"  wrote {out_path}")
        print("Done.")


if __name__ == "__main__":
    main()
